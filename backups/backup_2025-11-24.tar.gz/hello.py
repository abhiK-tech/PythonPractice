name = "Abhi"
env = "dev"
print("hello",name)