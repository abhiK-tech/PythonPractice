num1 = int(input("enter first number:")) 
num2 = int(input("enter second number:"))

sum_of_number = num1 + num2

print("total:", sum_of_number)